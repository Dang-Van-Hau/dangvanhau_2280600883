<?php include 'app/views/shares/header.php'; ?>

<div class="container mt-4">
    <h1 class="text-center mb-4">Danh sách sản phẩm</h1>
    <a href="/webbanhang/Product/add" class="btn btn-success mb-3">➕ Thêm sản phẩm mới</a>

    <div class="container mb-4">
        <ul class="nav nav-pills justify-content-center">
            <?php foreach ($categories as $key => $value): ?>
                <li class="nav-item">
                    <a class="nav-link <?= ($selectedCategory === $key) ? 'active' : '' ?> text-nowrap" href="?category=<?= $key; ?>"><?= $value; ?></a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>

    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
        <?php foreach ($products as $product): ?>
            <?php if ($selectedCategory === 'all' || (isset($product->category_name) && $product->category_name === $selectedCategory)): ?>
                <div class="col">
                    <div class="card h-100 shadow-sm">
                        <img src="/webbanhang/<?= $product->image ?: 'images/no-image.png'; ?>" class="card-img-top" alt="<?= htmlspecialchars($product->name); ?>" style="height: 200px; object-fit: cover;">
                        <div class="card-body text-center">
                            <h5 class="card-title">
                                <a href="/webbanhang/Product/show/<?= $product->id; ?>" class="text-decoration-none text-dark">
                                    <?= htmlspecialchars($product->name, ENT_QUOTES, 'UTF-8'); ?>
                                </a>
                            </h5>
                            <p class="card-text text-muted small">Giá: <strong class="text-danger"><?= number_format($product->price, 0, ',', '.'); ?> VND</strong></p>
                            <p class="card-text small">Danh mục: <span class="badge bg-primary"><?= htmlspecialchars($product->category_name, ENT_QUOTES, 'UTF-8'); ?></span></p>
                            <div class="d-flex justify-content-between">
                                <a href="/webbanhang/Product/edit/<?= $product->id; ?>" class="btn btn-warning btn-sm text-nowrap">✏️ Sửa</a>
                                <a href="/webbanhang/Product/delete/<?= $product->id; ?>" class="btn btn-danger btn-sm text-nowrap" onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?');">🗑 Xóa</a>
                            </div>
                            <div class="mt-2">
                                <a href="/webbanhang/Product/addToCart/<?= $product->id; ?>" class="btn btn-primary btn-sm text-nowrap">🛒 Thêm vào giỏ hàng</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>

    <h2 class="mt-5">Giỏ hàng</h2>
    <form id="cartForm" action="/webbanhang/Product/updateCart" method="POST">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th class="align-middle">Hình ảnh</th>
                        <th class="align-middle">Tên sản phẩm</th>
                        <th class="align-middle">Giá</th>
                        <th class="align-middle">Số lượng</th>
                        <th class="align-middle">Thành tiền</th>
                        <th class="align-middle">Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])): ?>
                        <?php $total = 0; ?>
                        <?php foreach ($_SESSION['cart'] as $productId => $product): ?>
                            <tr>
                                <td class="align-middle"><img src="/webbanhang/<?= $product['image']; ?>" style="max-width: 50px;" alt="<?= htmlspecialchars($product['name']); ?>"></td>
                                <td class="align-middle"><?= htmlspecialchars($product['name'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td class="align-middle text-danger"><?= number_format($product['price'], 0, ',', '.'); ?> VND</td>
                                <td class="align-middle">
                                    <input type="number" name="quantities[<?= $productId; ?>]" value="<?= $product['quantity']; ?>" min="1" class="form-control">
                                </td>
                                <td class="align-middle"><?= number_format($product['price'] * $product['quantity'], 0, ',', '.'); ?> VND</td>
                                <td class="align-middle">
                                    <a href="/webbanhang/Product/removeFromCart/<?= $productId; ?>" class="btn btn-danger btn-sm text-nowrap">🗑 Xóa</a>
                                </td>
                            </tr>
                            <?php $total += $product['price'] * $product['quantity']; ?>
                        <?php endforeach; ?>
                        <tr>
                            <td colspan="4" class="text-right"><strong>Tổng tiền:</strong></td>
                            <td colspan="2"><strong><?= number_format($total, 0, ',', '.'); ?> VND</strong></td>
                        </tr>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center">Giỏ hàng trống.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])): ?>
            <button type="submit" class="btn btn-primary">🔄 Cập nhật giỏ hàng</button>
            <?