<?php include 'app/views/shares/header.php'; ?>

<div class="container mt-4">
    <h1 class="text-center mb-4">🛒 Giỏ hàng của bạn</h1>

    <?php if (empty($_SESSION['cart'])): ?>
        <div class="alert alert-warning text-center">
            🛍 Giỏ hàng của bạn đang trống. <a href="/webbanhang/product">Mua sắm ngay!</a>
        </div>
    <?php else: ?>
        <form action="/webbanhang/Product/updateCart" method="post">
            <table class="table table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>Hình ảnh</th>
                        <th>Tên sản phẩm</th>
                        <th>Giá</th>
                        <th>Số lượng</th>
                        <th>Thành tiền</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        $totalPrice = 0;
                        foreach ($_SESSION['cart'] as $id => $item): 
                            $itemTotal = $item['price'] * $item['quantity'];
                            $totalPrice += $itemTotal;
                    ?>
                        <tr>
                            <td><img src="/webbanhang/<?= $item['image']; ?>" width="60" alt="Ảnh sản phẩm"></td>
                            <td><?= htmlspecialchars($item['name']); ?></td>
                            <td><strong class="text-danger"><?= number_format($item['price']); ?> VND</strong></td>
                            <td>
                                <input type="number" name="quantities[<?= $id; ?>]" value="<?= $item['quantity']; ?>" min="1" class="form-control w-50">
                            </td>
                            <td><strong class="text-success"><?= number_format($itemTotal); ?> VND</strong></td>
                            <td>
                                <a href="/webbanhang/Product/removeFromCart/<?= $id; ?>" class="btn btn-danger btn-sm">🗑 Xóa</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div class="d-flex justify-content-between align-items-center">
                <h4>Tổng tiền: <strong class="text-danger"><?= number_format($totalPrice); ?> VND</strong></h4>
                <div>
                    <button type="submit" class="btn btn-primary">🔄 Cập nhật giỏ hàng</button>
                    <a href="/webbanhang/Product/checkout" class="btn btn-success">💳 Thanh toán</a>
                </div>
            </div>
        </form>
    <?php endif; ?>
</div>

<?php include 'app/views/shares/footer.php'; ?>
