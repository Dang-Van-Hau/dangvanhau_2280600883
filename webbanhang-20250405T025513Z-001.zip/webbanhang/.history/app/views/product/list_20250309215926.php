<?php include 'app/views/shares/header.php'; ?>

<div class="container mt-4">
    <h1 class="text-center mb-4">Danh sách sản phẩm</h1>
    <a href="/webbanhang/Product/add" class="btn btn-success mb-3">➕ Thêm sản phẩm mới</a>

    <!-- Danh mục sản phẩm -->
    <?php
    $selectedCategory = isset($_GET['category']) ? $_GET['category'] : 'all';
    ?>
    <div class="categories mb-4">
        <ul class="nav nav-pills justify-content-center">
            <li class="nav-item"><a class="nav-link <?php echo ($selectedCategory === 'all') ? 'active' : ''; ?>" href="?category=all">Tất cả</a></li>
            <li class="nav-item"><a class="nav-link <?php echo ($selectedCategory === 'Điện thoại') ? 'active' : ''; ?>" href="?category=Điện thoại">Điện thoại</a></li>
            <li class="nav-item"><a class="nav-link <?php echo ($selectedCategory === 'Laptop') ? 'active' : ''; ?>" href="?category=Laptop">Laptop</a></li>
            <li class="nav-item"><a class="nav-link <?php echo ($selectedCategory === 'Phụ kiện') ? 'active' : ''; ?>" href="?category=Phụ kiện">Phụ kiện</a></li>
            <li class="nav-item"><a class="nav-link <?php echo ($selectedCategory === 'Thiết bị âm thanh') ? 'active' : ''; ?>" href="?category=Thiết bị âm thanh">Thiết bị âm thanh</a></li>
        </ul>
    </div>

    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 g-4">
        <?php foreach ($products as $product): ?>
            <?php if ($selectedCategory === 'all' || $product->category_name === $selectedCategory): ?>
                <div class="col">
                    <div class="card h-100 shadow-sm">
                        <div class="position-relative">
                            <?php if ($product->image): ?>
                                <img src="/webbanhang/<?php echo $product->image; ?>" class="card-img-top" alt="Product Image" style="height: 200px; object-fit: cover;">
                            <?php else: ?>
                                <img src="/webbanhang/images/no-image.png" class="card-img-top" alt="No Image" style="height: 200px; object-fit: cover;">
                            <?php endif; ?>
                        </div>
                        <div class="card-body text-center">
                            <h5 class="card-title">
                                <a href="/webbanhang/Product/show/<?php echo $product->id; ?>" class="text-decoration-none text-dark">
                                    <?php echo htmlspecialchars($product->name, ENT_QUOTES, 'UTF-8'); ?>
                                </a>
                            </h5>
                            <p class="card-text text-muted small">Giá: <strong class="text-danger"> <?php echo htmlspecialchars($product->price, ENT_QUOTES, 'UTF-8'); ?> VND</strong></p>
                            <p class="card-text small">Danh mục: <span class="badge bg-primary"> <?php echo htmlspecialchars($product->category_name, ENT_QUOTES, 'UTF-8'); ?> </span></p>
                            <div class="d-flex justify-content-between">
                                <a href="/webbanhang/Product/edit/<?php echo $product->id; ?>" class="btn btn-warning btn-sm">✏️ Sửa</a>
                                <a href="/webbanhang/Product/delete/<?php echo $product->id; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?');">🗑 Xóa</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
</div>

<style>
    .banner img {
        border-radius: 10px;
    }
    .categories .nav-link {
        font-size: 16px;
        font-weight: 500;
        padding: 10px 15px;
    }
    .categories .nav-link.active {
        background-color: #007bff;
        color: #fff;
    }
</style>

<script>
    // Khi nhấn vào "Quản lý sản phẩm", quay lại trang chủ
    document.querySelector("a[href='/webbanhang/Product/manage']").addEventListener("click", function(event) {
        event.preventDefault();
        window.location.href = "/webbanhang";
    });
</script>

<?php include 'app/views/shares/footer.php'; ?>
