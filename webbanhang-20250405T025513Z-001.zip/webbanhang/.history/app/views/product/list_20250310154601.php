<?php include 'app/views/shares/header.php'; ?>

<div class="container mt-4">
    <h1 class="text-center mb-4">Danh sách sản phẩm</h1>
    <a href="/webbanhang/Product/add" class="btn btn-success mb-3">➕ Thêm sản phẩm mới</a>   
    <a href="/webbanhang/Product/cart" class="btn btn-success mb-3">🛒 Giỏ hàng</a>

    <?php $selectedCategory = $_GET['category'] ?? 'all'; ?>
    <div class="categories mb-4">
        <ul class="nav nav-pills justify-content-center">
            <?php
            $categories = ['all' => 'Tất cả', 'Điện thoại' => 'Điện thoại', 'Laptop' => 'Laptop', 'Phụ kiện' => 'Phụ kiện', 'Thiết bị âm thanh' => 'Thiết bị âm thanh'];
            foreach ($categories as $key => $value) :
            ?>
                <li class="nav-item">
                    <a class="nav-link <?= ($selectedCategory === $key) ? 'active' : '' ?>" href="?category=<?= $key; ?>"><?= $value; ?></a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>

    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
        <?php foreach ($products as $product) : ?>
            <?php if ($selectedCategory === 'all' || $product->category_name === $selectedCategory) : ?>
                <div class="col">
                    <div class="card h-100 shadow-sm">
                        <img src="/webbanhang/<?= $product->image ?: 'images/no-image.png'; ?>" class="card-img-top" alt="Product Image" style="height: 300px; object-fit: cover;">
                        <div class="card-body text-center">
                            <h5 class="card-title">
                                <a href="/webbanhang/Product/show/<?= $product->id; ?>" class="text-decoration-none text-dark">
                                    <?= htmlspecialchars($product->name, ENT_QUOTES, 'UTF-8'); ?>
                                </a>
                            </h5>
                            <p class="card-text text-muted small">Giá: <strong class="text-danger"><?= number_format($product->price, 0, ',', '.'); ?> VND</strong></p>
                            <p class="card-text small">Danh mục: <span class="badge bg-primary"><?= htmlspecialchars($product->category_name, ENT_QUOTES, 'UTF-8'); ?></span></p>
                            <div class="row justify-content-center">
                                <div class="col-auto">
                                    <div class="d-flex" style="gap: 35px;">
                                        <a href="/webbanhang/Product/edit/<?= $product->id; ?>" class="btn btn-warning btn-sm">✏️ Sửa</a>
                                        <a href="/webbanhang/Product/delete/<?= $product->id; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?');"> Xóa</a>
                                    </div>
                                </div>
                            </div>
                            <div class="mt-2">
                                <a href="/webbanhang/Product/addToCart/<?= $product->id; ?>" class="btn btn-primary btn-sm"> Thêm vào giỏ hàng</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
</div>

<style>
    .categories .nav-link {
        font-size: 16px;
        font-weight: 500;
        padding: 10px 15px;
    }

    .categories .nav-link.active {
        background-color: #007bff;
        color: #fff;
    }
</style>

<?php include 'app/views/shares/footer.php'; ?>