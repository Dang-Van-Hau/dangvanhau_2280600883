<?php include 'app/views/shares/header.php'; ?>

<div class="container mt-4">
    <h1 class="text-center mb-4">Quản lý sản phẩm</h1>

    <!-- Tabs Navigation -->
    <ul class="nav nav-tabs" id="productTabs">
        <li class="nav-item">
            <a class="nav-link active" data-tab="list" href="#">Danh sách sản phẩm</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-tab="add" href="#">➕ Thêm sản phẩm mới</a>
        </li>
    </ul>

    <!-- Content Area -->
    <div id="tabContent" class="mt-3"></div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        function loadTabContent(tab) {
            let url = tab === "list" ? "/webbanhang/Product/list" : "/webbanhang/Product/add";
            fetch(url)
                .then(response => response.text())
                .then(html => {
                    document.getElementById("tabContent").innerHTML = html;
                })
                .catch(error => console.error("Lỗi tải nội dung:", error));
        }

        document.querySelectorAll("[data-tab]").forEach(tabLink => {
            tabLink.addEventListener("click", function (e) {
                e.preventDefault();
                document.querySelector(".nav-link.active").classList.remove("active");
                this.classList.add("active");
                loadTabContent(this.getAttribute("data-tab"));
            });
        });

        // Load default tab content
        loadTabContent("list");
    });
</script>

<?php include 'app/views/shares/footer.php'; ?>
