<?php include 'app/views/shares/header.php'; ?>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        function loadTabContent(tab) {
            let url = tab === "list" ? "/webbanhang/Product/list" : "/webbanhang/Product/add";
            fetch(url)
                .then(response => response.text())
                .then(html => {
                    document.getElementById("tabContent").innerHTML = html;
                })
                .catch(error => console.error("Lỗi tải nội dung:", error));
        }

        document.querySelectorAll("[data-tab]").forEach(tabLink => {
            tabLink.addEventListener("click", function (e) {
                e.preventDefault();
                document.querySelector(".nav-link.active").classList.remove("active");
                this.classList.add("active");
                loadTabContent(this.getAttribute("data-tab"));
            });
        });

        // Load default tab content
        loadTabContent("list");
    });
</script>

<?php include 'app/views/shares/footer.php'; ?>
