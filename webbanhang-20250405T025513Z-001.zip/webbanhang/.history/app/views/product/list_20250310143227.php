<?php include 'app/views/shares/header.php'; ?>

<div class="container mt-4">
    <h1 class="text-center mb-4">Danh sách sản phẩm</h1>
    <a href="/webbanhang/Product/add" class="btn btn-success mb-3">➕ Thêm sản phẩm mới</a>

    <!-- Lọc danh mục sản phẩm -->
    <div class="container mb-4">
        <ul class="nav nav-pills justify-content-center">
            <?php foreach ($categories as $key => $value): ?>
                <li class="nav-item">
                    <a class="nav-link <?= ($selectedCategory === $key) ? 'active' : '' ?>" href="?category=<?= $key; ?>"><?= $value; ?></a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>

    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
        <?php if (!empty($products)): ?>
            <?php foreach ($products as $product): ?>
                <?php if ($selectedCategory === 'all' || (isset($product->category_name) && $product->category_name === $selectedCategory)): ?>
                    <div class="col">
                        <div class="card h-100 shadow-sm">
                            <img src="/webbanhang/<?= $product->image ?: 'images/no-image.png'; ?>" class="card-img-top" alt="<?= htmlspecialchars($product->name); ?>" style="height: 200px; object-fit: cover;">
                            <div class="card-body text-center">
                                <h5 class="card-title">
                                    <a href="/webbanhang/Product/show/<?= $product->id; ?>" class="text-decoration-none text-dark">
                                        <?= htmlspecialchars($product->name, ENT_QUOTES, 'UTF-8'); ?>
                                    </a>
                                </h5>
                                <p class="card-text text-muted small">Giá: <strong class="text-danger"><?= number_format($product->price, 0, ',', '.'); ?> VND</strong></p>
                                <p class="card-text small">Danh mục: <span class="badge bg-primary"><?= htmlspecialchars($product->category_name, ENT_QUOTES, 'UTF-8'); ?></span></p>
                                
                                <div class="btn-group d-flex justify-content-center mt-2">
                                    <a href="/webbanhang/Product/edit/<?= $product->id; ?>" class="btn btn-warning btn-sm">✏️ Sửa</a>
                                    <a href="/webbanhang/Product/delete/<?= $product->id; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này?');">🗑 Xóa</a>
                                </div>
                                <a href="/webbanhang/Product/addToCart/<?= $product->id; ?>" class="btn btn-primary btn-sm w-100 mt-2">🛒 Thêm vào giỏ hàng</a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="text-center text-muted">Không có sản phẩm nào.</p>
        <?php endif; ?>
    </div>

    <!-- Giỏ hàng -->
    <h2 class="mt-5">Giỏ hàng</h2>
    <form id="cartForm" action="/webbanhang/Product/updateCart" method="POST">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Hình ảnh</th>
                        <th>Tên sản phẩm</th>
                        <th>Giá</th>
                        <th>Số lượng</th>
                        <th>Thành tiền</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($_SESSION['cart'])): ?>
                        <?php $total = 0; ?>
                        <?php foreach ($_SESSION['cart'] as $productId => $product): ?>
                            <tr>
                                <td><img src="/webbanhang/<?= $product['image']; ?>" style="max-width: 50px;" alt="<?= htmlspecialchars($product['name']); ?>"></td>
                                <td><?= htmlspecialchars($product['name'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td class="text-danger"><?= number_format($product['price'], 0, ',', '.'); ?> VND</td>
                                <td>
                                    <input type="number" name="quantities[<?= $productId; ?>]" value="<?= $product['quantity']; ?>" min="1" class="form-control">
                                </td>
                                <td><?= number_format($product['price'] * $product['quantity'], 0, ',', '.'); ?> VND</td>
                                <td>
                                    <a href="/webbanhang/Product/removeFromCart/<?= $productId; ?>" class="btn btn-danger btn-sm">🗑 Xóa</a>
                                </td>
                            </tr>
                            <?php $total += $product['price'] * $product['quantity']; ?>
                        <?php endforeach; ?>
                        <tr>
                            <td colspan="4" class="text-right"><strong>Tổng tiền:</strong></td>
                            <td colspan="2"><strong><?= number_format($total, 0, ',', '.'); ?> VND</strong></td>
                        </tr>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center">Giỏ hàng trống.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if (!empty($_SESSION['cart'])): ?>
            <button type="submit" class="btn btn-primary w-100 mt-3">🔄 Cập nhật giỏ hàng</button>
        <?php endif; ?>
    </form>
</div>

<style>
    .nav-link {
        font-size: 16px;
        font-weight: 500;
        padding: 10px 15px;
    }
    .nav-link.active {
        background-color: #007bff;
        color: #fff;
    }
    .btn-group .btn {
        flex: 1;
        margin: 0 2px;
    }
    .table img {
        border-radius: 5px;
    }
</style>

<?php include 'app/views/shares/footer.php'; ?>
