<?php

session_start();

require_once 'app/models/ProductModel.php';

try {
    $url = $_GET['url'] ?? '';
    $url = rtrim($url, '/');
    $url = filter_var($url, FILTER_SANITIZE_URL);
    $urlParts = explode('/', $url);

    $controllerName = isset($urlParts[0]) && $urlParts[0] != '' ? ucfirst($urlParts[0]) . 'Controller' : 'DefaultController';
    $action = isset($urlParts[1]) && $urlParts[1] != '' ? $urlParts[1] : 'index';

    $controllerFilePath = 'app/controllers/' . $controllerName . '.php';

    if (!file_exists($controllerFilePath)) {
        throw new Exception('Controller not found: ' . $controllerName);
    }

    require_once $controllerFilePath;
    $controller = new $controllerName();

    if (!method_exists($controller, $action)) {
        throw new Exception('Action not found: ' . $action . ' in ' . $controllerName);
    }

    call_user_func_array([$controller, $action], array_slice($urlParts, 2));
} catch (Exception $e) {
    error_log('Error in router: ' . $e->getMessage());
    echo 'An error occurred. Please try again later.';
}

?>