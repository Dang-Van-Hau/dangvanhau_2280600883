<?php
// Yêu cầu file model ProductModel
require_once 'app/models/ProductModel.php';

// Lấy URL từ tham số GET, loại bỏ dấu gạch chéo cuối, lọc và tách thành mảng
$url = $_GET['url'] ?? '';
$url = rtrim($url, '/');
$url = filter_var($url, FILTER_SANITIZE_URL);
$url = explode('/', $url);

// Xác định tên controller từ phần tử đầu tiên của URL
$controllerName = isset($url[0]) && $url[0] != '' ? ucfirst($url[0]) . 'Controller' : 'DefaultController';

// Xác định tên action từ phần tử thứ hai của URL
$action = isset($url[1]) && $url[1] != '' ? $url[1] : 'index';

// Kiểm tra xem file controller có tồn tại không
if (!file_exists('app/controllers/' . $controllerName . '.php')) {
    // Xử lý nếu controller không tồn tại
    die('Controller not found');
}

// Yêu cầu file controller
require_once 'app/controllers/' . $controllerName . '.php';

// Tạo instance của controller
$controller = new $controllerName();

// Kiểm tra xem action có tồn tại trong controller không
if (!method_exists($controller, $action)) {
    // Xử lý nếu action không tồn tại
    die('Action not found');
}

// Gọi action với các tham số còn lại từ URL
call_user_func_array([$controller, $action], array_slice($url, 2));
?>