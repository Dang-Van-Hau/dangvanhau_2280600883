<?php
// Kiểm tra session trước khi khởi động
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'app/models/ProductModel.php';
require_once 'app/helpers/SessionHelper.php';

try {
    // Lấy và xử lý URL
    $url = $_GET['url'] ?? '';
    $url = trim($url, '/');
    $url = filter_var($url, FILTER_SANITIZE_URL);
    $urlParts = explode('/', $url);

    // Xác định Controller & Action mặc định
    $controllerName = !empty($urlParts[0]) ? ucfirst($urlParts[0]) . 'Controller' : 'ProductController';
    $action = $urlParts[1] ?? 'index';

    $controllerFilePath = "app/controllers/{$controllerName}.php";

    // Kiểm tra file controller
    if (!file_exists($controllerFilePath)) {
        throw new Exception("Controller not found: {$controllerName}");
    }

    require_once $controllerFilePath;

    // Kiểm tra class có tồn tại không
    if (!class_exists($controllerName)) {
        throw new Exception("Class not found: {$controllerName}");
    }

    // Khởi tạo controller
    $controller = new $controllerName();

    // Kiểm tra action có tồn tại không
    if (!method_exists($controller, $action)) {
        throw new Exception("Action not found: {$action} in {$controllerName}");
    }

    // Lấy tham số còn lại từ URL
    $params = array_slice($urlParts, 2);

    // Gọi action với tham số
    call_user_func_array([$controller, $action], $params);
} catch (Exception $e) {
    error_log("[ERROR] Router: " . $e->getMessage());
    
    // Chuyển hướng đến trang lỗi thay vì hiển thị lỗi trực tiếp
    header("Location: /error");
    exit;
}
?>
